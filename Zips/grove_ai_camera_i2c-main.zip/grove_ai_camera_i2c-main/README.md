This is the example for Grove AI Camera.
